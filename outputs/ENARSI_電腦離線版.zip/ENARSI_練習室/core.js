(function(root){
'use strict';
const normal=s=>String(s||'').toLowerCase().replace(/[^a-z0-9\u4e00-\u9fff]/g,'');
const idOK=s=>/^[ABC][1-9]\d{0,4}$/.test(s);
function shuffled(items,random=Math.random){const a=[...items];for(let i=a.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}
function sameSet(a,b){return Array.isArray(a)&&Array.isArray(b)&&a.length===b.length&&new Set(a).size===a.length&&a.every(x=>b.includes(x));}
function grade(q,answer,note){if(q.type==='choice')return sameSet(answer||[],q.answer||[]);if(note?.drag?.pairs){const pairs=note.drag.pairs;return pairs.length>0&&pairs.every(([target,item])=>answer?.[item]===target)&&Object.keys(answer||{}).length===new Set(pairs.map(p=>p[1])).size;}return null;}
function remaining(exam,now=Date.now()){return Math.max(0,Math.ceil((exam.deadline-now)/1000));}
function formatTime(seconds){const s=Math.max(0,Math.floor(seconds));return `${String(Math.floor(s/60)).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`;}
function safeHTML(html){
 if(typeof DOMParser==='undefined')throw Error('需要瀏覽器才能處理網頁內容');
 const pre=String(html||'').replace(/<(script|style|iframe|object|embed|svg|form)\b[^>]*>[\s\S]*?<\/\1\s*>/gi,'').replace(/<(img|link|input|meta|base)\b[^>]*>/gi,'');
 const doc=new DOMParser().parseFromString(pre,'text/html');
 const allowed=new Set('p br hr div span strong b em i u ul ol li table thead tbody tr td th code pre h2 h3 h4 blockquote a'.split(' '));
 function clean(node){if(node.nodeType===3)return document.createTextNode(node.textContent);if(node.nodeType!==1)return document.createTextNode('');let tag=node.tagName.toLowerCase();if(tag==='button')tag='h3';if(tag==='span'&&/Consolas|monospace/.test(node.getAttribute('style')||''))tag='code';const el=document.createElement(allowed.has(tag)?tag:'span');if(tag==='a'){const href=node.getAttribute('href')||'';if(/^https:\/\//i.test(href)){el.href=href;el.target='_blank';el.rel='noopener noreferrer';}}for(const child of node.childNodes)el.appendChild(clean(child));return el;}
 const box=document.createElement('div');for(const n of doc.body.childNodes)box.appendChild(clean(n));return box.innerHTML;
}
function validateNotes(notes,questions){
 const known=new Set(questions.map(q=>q.id)),out={};
 for(const [id,n] of Object.entries(notes||{})){
  if(!idOK(id)||!known.has(id)||!n||typeof n!=='object')continue;
  const optionsZh={};for(const [k,v] of Object.entries(n.optionsZh||{}))if(/^[A-H]$/.test(k))optionsZh[k]=String(v).slice(0,10000);
  const v={id,stemZh:String(n.stemZh||'').slice(0,30000),optionsZh,html:safeHTML(String(n.html||'').slice(0,300000)),source:String(n.source||'使用者提供的 BGW 原文').slice(0,150),imported:String(n.imported||new Date().toISOString()),english:String(n.english||'').slice(0,30000)};
  if(n.drag&&['drag_category','drag_match'].includes(n.drag.type)&&Array.isArray(n.drag.pairs)){const pairs=n.drag.pairs.filter(p=>Array.isArray(p)&&p.length===2&&p.every(x=>typeof x==='string'&&x.length<5000)).slice(0,100);if(pairs.length&&new Set(pairs.map(p=>p[1])).size===pairs.length)v.drag={type:n.drag.type,pairs};}
  out[id]=v;
 }
 return out;
}
function validateBank(bank){
 if(!bank||!Array.isArray(bank.questions)||!bank.questions.length||bank.questions.length>10000)throw Error('這不是有效的 ENARSI 題庫包。');
 const seen=new Set();
 for(const q of bank.questions){
  if(!idOK(q.id)||seen.has(q.id)||!['choice','drag','lab'].includes(q.type)||typeof q.stem!=='string')throw Error('題庫題號或內容格式不正確。');seen.add(q.id);
  if(!Array.isArray(q.images)||!Array.isArray(q.solution)||![...q.images,...q.solution].every(s=>typeof s==='string'&&(/^(data:image\/(webp|png|jpeg);base64,)/.test(s)||/^assets\/[\w.-]+\.(webp|png|jpg)$/.test(s))))throw Error('題庫內的圖片格式不正確。');
  if(q.type==='choice'&&(!Array.isArray(q.options)||!Array.isArray(q.answer)||!q.answer.length||!q.answer.every(a=>q.options.some(o=>o.label===a))||!q.options.every(o=>/^[A-H]$/.test(o.label)&&typeof o.text==='string')))throw Error('選項與答案不完整。');
 }
 return bank;
}
function parseBGW(source,questions){
 const text=String(source||'').trim();if(!text)throw Error('請先貼上題目網頁的原始碼或內容。');if(text.length>3000000)throw Error('一次請貼上一題，或改用檔案匯入。');
 // Inert parsing: remove network-capable elements before constructing the detached document.
 const safeSource=text.replace(/<(iframe|object|embed|style)\b[^>]*>[\s\S]*?<\/\1\s*>/gi,'').replace(/<(img|link|meta|base)\b[^>]*>/gi,'');
 const doc=new DOMParser().parseFromString(safeSource,'text/html');
 const en=doc.querySelector('.question-text:not(.question-text-zh)')?.textContent?.trim();
 if(!en)throw Error('沒有找到題幹。請複製題目的網頁原始碼，或選取整題後複製（包含題號與筆記）。');
 const match=questions.find(q=>normal(q.stem)===normal(en))||questions.find(q=>normal(q.stem).startsWith(normal(en))&&normal(en).length>30);
 if(!match)throw Error('這個題幹不在目前的題庫中，請先確認是 300-410 的同一版題庫。');
 const optionsZh={};for(const row of doc.querySelectorAll('.choice-row')){const label=row.querySelector('.choice-label')?.textContent?.trim().replace('.','');const zh=row.querySelector('.choice-text-zh')?.textContent?.trim();if(/^[A-H]$/.test(label)&&zh)optionsZh[label]=zh;}
 let drag=null;try{drag=JSON.parse(doc.querySelector('#practice-correct-drag')?.textContent||'null');}catch{}
 const raw={id:match.id,stemZh:doc.querySelector('.question-text-zh')?.textContent?.trim()||'',optionsZh,html:doc.querySelector('.note-content')?.innerHTML||'',source:'BGW 原文（使用者複製的網頁）',imported:new Date().toISOString(),english:en,drag};
 if(!raw.stemZh&&!raw.html&&!drag)throw Error('找到了題目，但沒有中文或配對資料。請確認已複製完整的題目原始碼。');
 return validateNotes({[match.id]:raw},questions)[match.id];
}
function mergeNotes(old,incoming){const result={...old};for(const [id,n]of Object.entries(incoming)){const before=result[id]||{};result[id]={...before,...n,stemZh:n.stemZh||before.stemZh||'',html:n.html||before.html||'',optionsZh:{...(before.optionsZh||{}),...(n.optionsZh||{})},...(n.drag||before.drag?{drag:n.drag||before.drag}:{})};}return result;}
const api={normal,idOK,shuffled,sameSet,grade,remaining,formatTime,safeHTML,validateNotes,validateBank,parseBGW,mergeNotes};
if(typeof module!=='undefined'&&module.exports)module.exports=api;root.StudyCore=api;
})(typeof globalThis!=='undefined'?globalThis:this);
